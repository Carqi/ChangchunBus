package com.carqi.ccbus.data;

import java.io.Serializable;

@SuppressWarnings("serial")
public class BusStation implements Serializable {
	private String station;
	private String firstLetter;
	private String allLetter;

	public BusStation() {
	}
	public BusStation(String station) {
		this.station = station;
	}
	public BusStation(String station, String firstLetter, String allLetter){
		this.station = station;
		this.firstLetter = station;
		this.allLetter = station;
	}

	public String getStation() {
		return station;
	}

	public void setStation(String station) {
		this.station = station;
	}
	public String getFirstLetter() {
		return firstLetter;
	}
	public void setFirstLetter(String firstLetter) {
		this.firstLetter = firstLetter;
	}
	public String getAllLetter() {
		return allLetter;
	}
	public void setAllLetter(String allLetter) {
		this.allLetter = allLetter;
	}
	
	
}
